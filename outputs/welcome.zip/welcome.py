def hello(event, context):
    print("Barev aper")